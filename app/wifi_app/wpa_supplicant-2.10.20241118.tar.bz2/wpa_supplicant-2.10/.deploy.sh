#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## wpa_supplicant-2.10: deploy ##########"
cd /home/xy/sdk/6.10/rk3506/buildroot
cd /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/target
/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/bin/tar --no-recursion --ignore-failed-read -cf /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/wpa_supplicant-2.10/wpa_supplicant-2.10.tar -T /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/wpa_supplicant-2.10/.files-list-target.txt
adb shell true >/dev/null
adb push /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/wpa_supplicant-2.10/wpa_supplicant-2.10.tar /tmp/
adb shell tar xvf /tmp/wpa_supplicant-2.10.tar
