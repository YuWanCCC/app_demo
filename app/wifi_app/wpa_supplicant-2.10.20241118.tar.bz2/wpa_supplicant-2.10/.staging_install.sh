#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## wpa_supplicant-2.10: staging install ##########"
cd /home/xy/sdk/6.10/rk3506/buildroot
/usr/bin/install -m 0644 -D /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/wpa_supplicant-2.10/wpa_supplicant/libwpa_client.so /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot/usr/lib/libwpa_client.so
/usr/bin/install -m 0644 -D /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/wpa_supplicant-2.10/src/common/wpa_ctrl.h /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot/usr/include/wpa_ctrl.h
cd /home/xy/sdk/6.10/rk3506/buildroot
rm -f -rf  /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot/share/info/dir
cd /home/xy/sdk/6.10/rk3506/buildroot
if test -n "" ; then echo "[7m>>> wpa_supplicant 2.10 Fixing package configuration files[27m" ; /usr/bin/sed -i -e  "s,/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host,@HOST_DIR@,g" -e "s,/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506,@BASE_DIR@,g" -e "s,^\(exec_\)\?prefix=.*,\1prefix=@STAGING_DIR@/usr,g" -e "s,-I/usr/,-I@STAGING_DIR@/usr/,g" -e "s,-L/usr/,-L@STAGING_DIR@/usr/,g" -e 's,@STAGING_DIR@,$(dirname $(readlink -e $0))/../..,g' -e 's,@HOST_DIR@,$(dirname $(readlink -e $0))/../../../..,g' -e "s,@BASE_DIR@,/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506,g"  ; fi
echo "[7m>>> wpa_supplicant 2.10 Fixing libtool files[27m"
for la in $(find /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot/usr/lib* -name "*.la"); do cp -a "${la}" "${la}.fixed" && /usr/bin/sed -i -e "s:/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506:@BASE_DIR@:g" -e "s:/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot:@STAGING_DIR@:g"  -e "s:\(['= ]\)/usr:\\1@STAGING_DIR@/usr:g" -e "s:\(['= ]\)/lib:\\1@STAGING_DIR@/lib:g"  -e "s:@STAGING_DIR@:/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/arm-buildroot-linux-gnueabihf/sysroot:g" -e "s:@BASE_DIR@:/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506:g" "${la}.fixed" && if cmp -s "${la}" "${la}.fixed"; then rm -f "${la}.fixed"; else mv "${la}.fixed" "${la}"; fi || exit 1; done
