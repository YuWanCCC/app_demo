#!/bin/sh -e
[ -z "$DEBUG" ] || set -x
echo "########## hostapd-2.10: update ##########"
cd /home/xy/sdk/6.10/rk3506/buildroot
[ -r /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/hostapd-2.10/.files-list-target-update.txt ] || exit 0
cd /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/target
/home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/host/bin/tar --no-recursion --ignore-failed-read -cf /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/hostapd-2.10/hostapd-2.10-update.tar -T /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/hostapd-2.10/.files-list-target-update.txt
adb shell true >/dev/null
adb push /home/xy/sdk/6.10/rk3506/buildroot/output/rockchip_rk3506/build/hostapd-2.10/hostapd-2.10-update.tar /tmp/
adb shell tar xvf /tmp/hostapd-2.10-update.tar
